# Leo Cards — Shop Phase 1
חבילת קלפי חנות ראשונה להטמעה באתר.

## סטטוס
- נוצרו והומרו: 40 קלפי חנות
- פורמט אתר: WebP, 768×1152, יחס 2:3
- אין טקסט בתוך התמונות; האתר מוסיף שם/מחיר/נדירות/נעילה.

## תיקיות
- `public/rewards/cards/shop/professions/`
- `public/rewards/cards/shop/space-tech/`
- `public/rewards/cards/shop/fantasy/`
- `public/rewards/cards/shop/sport-fun/`
- `public/rewards/cards/shop/style/`

## מיפוי קבצים
| שם קובץ | שם בעברית | נדירות | נתיב באתר |
|---|---|---|---|
| `leo_scientist.webp` | ליאו המדען | רגיל | `/rewards/cards/shop/professions/leo_scientist.webp` |
| `leo_detective.webp` | ליאו הבלש | רגיל | `/rewards/cards/shop/professions/leo_detective.webp` |
| `leo_doctor.webp` | ליאו הרופא | מיוחד | `/rewards/cards/shop/professions/leo_doctor.webp` |
| `leo_chef.webp` | ליאו השף | רגיל | `/rewards/cards/shop/professions/leo_chef.webp` |
| `leo_pilot.webp` | ליאו הטייס | מיוחד | `/rewards/cards/shop/professions/leo_pilot.webp` |
| `leo_engineer.webp` | ליאו המהנדס | מיוחד | `/rewards/cards/shop/professions/leo_engineer.webp` |
| `leo_artist.webp` | ליאו האמן | רגיל | `/rewards/cards/shop/professions/leo_artist.webp` |
| `leo_musician.webp` | ליאו המוזיקאי | רגיל | `/rewards/cards/shop/professions/leo_musician.webp` |
| `leo_astronaut.webp` | ליאו האסטרונאוט | נדיר | `/rewards/cards/shop/space-tech/leo_astronaut.webp` |
| `leo_space_commander.webp` | ליאו מפקד החלל | זהב | `/rewards/cards/shop/space-tech/leo_space_commander.webp` |
| `leo_star_explorer.webp` | ליאו חוקר הכוכבים | מיוחד | `/rewards/cards/shop/space-tech/leo_star_explorer.webp` |
| `leo_robotic.webp` | ליאו הרובוטי | נדיר | `/rewards/cards/shop/space-tech/leo_robotic.webp` |
| `leo_super_inventor.webp` | ליאו ממציא העל | נדיר | `/rewards/cards/shop/space-tech/leo_super_inventor.webp` |
| `leo_galaxy_captain.webp` | ליאו קפטן גלקסי | זהב | `/rewards/cards/shop/space-tech/leo_galaxy_captain.webp` |
| `leo_space_pilot.webp` | ליאו טייס חלל | מיוחד | `/rewards/cards/shop/space-tech/leo_space_pilot.webp` |
| `leo_technodog.webp` | ליאו טכנודוג | נדיר | `/rewards/cards/shop/space-tech/leo_technodog.webp` |
| `leo_wizard.webp` | ליאו הקוסם | מיוחד | `/rewards/cards/shop/fantasy/leo_wizard.webp` |
| `leo_sorcerer.webp` | ליאו המכשף | נדיר | `/rewards/cards/shop/fantasy/leo_sorcerer.webp` |
| `leo_knight.webp` | ליאו האביר | מיוחד | `/rewards/cards/shop/fantasy/leo_knight.webp` |
| `leo_pirate.webp` | ליאו הפיראט | רגיל | `/rewards/cards/shop/fantasy/leo_pirate.webp` |
| `leo_ninja.webp` | ליאו הנינג׳ה | נדיר | `/rewards/cards/shop/fantasy/leo_ninja.webp` |
| `leo_king.webp` | ליאו המלך | זהב | `/rewards/cards/shop/fantasy/leo_king.webp` |
| `leo_forest_guardian.webp` | ליאו שומר היער | מיוחד | `/rewards/cards/shop/fantasy/leo_forest_guardian.webp` |
| `leo_superhero.webp` | סופר ליאו | זהב | `/rewards/cards/shop/fantasy/leo_superhero.webp` |
| `leo_football.webp` | ליאו הכדורגלן | רגיל | `/rewards/cards/shop/sport-fun/leo_football.webp` |
| `leo_basketball.webp` | ליאו הכדורסלן | רגיל | `/rewards/cards/shop/sport-fun/leo_basketball.webp` |
| `leo_runner.webp` | ליאו הרץ | רגיל | `/rewards/cards/shop/sport-fun/leo_runner.webp` |
| `leo_swimmer.webp` | ליאו השחיין | מיוחד | `/rewards/cards/shop/sport-fun/leo_swimmer.webp` |
| `leo_surfer.webp` | ליאו הגולש | מיוחד | `/rewards/cards/shop/sport-fun/leo_surfer.webp` |
| `leo_dancer.webp` | ליאו הרקדן | רגיל | `/rewards/cards/shop/sport-fun/leo_dancer.webp` |
| `leo_champion.webp` | ליאו האלוף | נדיר | `/rewards/cards/shop/sport-fun/leo_champion.webp` |
| `leo_gamer.webp` | ליאו הגיימר | מיוחד | `/rewards/cards/shop/sport-fun/leo_gamer.webp` |
| `leo_smart.webp` | ליאו החכם | מיוחד | `/rewards/cards/shop/style/leo_smart.webp` |
| `leo_funny.webp` | ליאו המצחיק | רגיל | `/rewards/cards/shop/style/leo_funny.webp` |
| `leo_playful.webp` | ליאו השובב | רגיל | `/rewards/cards/shop/style/leo_playful.webp` |
| `leo_celebration.webp` | ליאו החוגג | מיוחד | `/rewards/cards/shop/style/leo_celebration.webp` |
| `leo_classic.webp` | ליאו הקלאסי | רגיל | `/rewards/cards/shop/style/leo_classic.webp` |
| `leo_glasses.webp` | ליאו עם משקפיים | רגיל | `/rewards/cards/shop/style/leo_glasses.webp` |
| `leo_suit.webp` | ליאו בחליפה | נדיר | `/rewards/cards/shop/style/leo_suit.webp` |
| `leo_cool.webp` | ליאו המגניב | מיוחד | `/rewards/cards/shop/style/leo_cool.webp` |
