LEO KIDS - Transparent 3 Portal Icons

זו גרסה ללא רקע מרובע/צבעוני מאחור.
מבוסס על אייקון הילד המקורי של ליאו, בלי להחליף את הכלב.

3 פורטלים:
- child   = ליאו + כוכב
- parent  = ליאו + משפחה/לב
- teacher = ליאו + ספר

בכל תיקייה:
- favicon.ico
- favicon PNG: 16, 24, 32, 48
- Android / PWA: 72, 96, 128, 144, 152, 192, 384, 512
- iOS / Apple Touch: 57, 60, 72, 76, 114, 120, 144, 152, 167, 180
- Windows tiles: 70, 150, 310, 310x150
- Maskable transparent icons: 192, 384, 512, 1024
- manifest-icons.json
- html-head-snippet.txt

המלצת נתיבים:
public/icons/child/
public/icons/parent/
public/icons/teacher/

הערה:
מכיוון שהאייקונים שקופים, המכשיר/דפדפן עשוי להציג צבע רקע משלו במסך הבית או במסך טעינה.
