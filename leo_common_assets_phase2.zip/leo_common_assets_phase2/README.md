# Leo Common Assets — Phase 2

חבילה זו כוללת 4 נכסים כלליים למערכת קלפי ליאו.

## קבצים

| קובץ | נתיב ציבורי | גודל | שימוש |
|---|---|---:|---|
| card_back.webp | /rewards/cards/common/card_back.webp | 768×1152 | גב קלף |
| surprise_box_icon.webp | /rewards/cards/common/surprise_box_icon.webp | 512×512 | אייקון קופסת הפתעה |
| duplicate_icon.webp | /rewards/cards/common/duplicate_icon.webp | 512×512 | אייקון כפילות |
| coin_convert_icon.webp | /rewards/cards/common/coin_convert_icon.webp | 512×512 | אייקון המרה למטבעות |

## מבנה יעד

להעתיק את התיקייה:

public/rewards/cards/common/

אל אותו הנתיב בפרויקט.

## הערות

- לא לשנות שמות קבצים.
- לא לשנות DB.
- לא לשנות כלכלת מטבעות.
- לא לשנות מחירים.
- האתר מוסיף טקסטים/סטטוסים/לוגיקה בעצמו.
