# Leo Achievement Cards — Phase 4 to 6 Remaining

חבילה זו כוללת את 16 קלפי ההישג שנשארו אחרי חבילת ההישגים הראשונה.

## מבנה יעד

להעתיק את התיקייה:

public/rewards/cards/achievements/

אל אותו הנתיב בפרויקט.

## קבצים

| קובץ | שם קלף | נדירות | קבוצה | נתיב ציבורי |
|---|---|---|---|---|
| achievement_number_explorer.webp | חוקר המספרים | רגיל | math | /rewards/cards/achievements/math/achievement_number_explorer.webp |
| achievement_addition_champion.webp | אלוף החיבור | מיוחד | math | /rewards/cards/achievements/math/achievement_addition_champion.webp |
| achievement_subtraction_champion.webp | אלוף החיסור | מיוחד | math | /rewards/cards/achievements/math/achievement_subtraction_champion.webp |
| achievement_multiplication_champion.webp | אלוף הכפל | נדיר | math | /rewards/cards/achievements/math/achievement_multiplication_champion.webp |
| achievement_division_champion.webp | אלוף החילוק | נדיר | math | /rewards/cards/achievements/math/achievement_division_champion.webp |
| achievement_shapes_master.webp | אמן הצורות | מיוחד | math | /rewards/cards/achievements/math/achievement_shapes_master.webp |
| achievement_young_reader.webp | קורא צעיר | רגיל | language | /rewards/cards/achievements/language/achievement_young_reader.webp |
| achievement_word_discoverer.webp | מגלה מילים | מיוחד | language | /rewards/cards/achievements/language/achievement_word_discoverer.webp |
| achievement_understanding_master.webp | אמן ההבנה | נדיר | language | /rewards/cards/achievements/language/achievement_understanding_master.webp |
| achievement_hebrew_star.webp | כוכב עברית | נדיר | language | /rewards/cards/achievements/language/achievement_hebrew_star.webp |
| achievement_english_star.webp | כוכב אנגלית | נדיר | language | /rewards/cards/achievements/language/achievement_english_star.webp |
| achievement_great_listener.webp | מאזין מצטיין | מיוחד | language | /rewards/cards/achievements/language/achievement_great_listener.webp |
| achievement_science_explorer.webp | חוקר המדע | מיוחד | subjects | /rewards/cards/achievements/subjects/achievement_science_explorer.webp |
| achievement_moledet_explorer.webp | חוקר המולדת | מיוחד | subjects | /rewards/cards/achievements/subjects/achievement_moledet_explorer.webp |
| achievement_personal_activity.webp | אלוף הפעילות האישית | נדיר | general | /rewards/cards/achievements/general/achievement_personal_activity.webp |
| achievement_new_record.webp | שיא אישי חדש | זהב | general | /rewards/cards/achievements/general/achievement_new_record.webp |

## כללים

- לא לשנות שמות קבצים.
- לא להוסיף טקסט לתמונות.
- לא לשנות DB.
- לא לשנות כלכלת מטבעות.
- לא לשנות לוגיקת הישגים.
- רק לחבר את התמונות לקלפי ההישג המתאימים.