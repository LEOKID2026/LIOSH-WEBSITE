# Leo Achievement Cards — Phase 3 General

חבילה זו כוללת 8 קלפי הישג ראשונים של ליאו.

## נתיב יעד

להעתיק את התיקייה:

public/rewards/cards/achievements/general/

אל אותו הנתיב בפרויקט.

## קבצים

| קובץ | שם קלף | נדירות |
|---|---|---|
| achievement_strong_start.webp | מתחיל חזק | רגיל |
| achievement_20_questions.webp | סיימתי 20 שאלות | רגיל |
| achievement_3_day_streak.webp | מתמיד 3 ימים | מיוחד |
| achievement_7_day_streak.webp | מתמיד 7 ימים | נדיר |
| achievement_week_star.webp | כוכב השבוע | זהב |
| achievement_never_give_up.webp | לא ויתרתי | נדיר |
| achievement_big_progress.webp | קפיצת מדרגה | נדיר |
| achievement_task_complete.webp | משימה הושלמה | מיוחד |

## כללים

- לא לשנות שמות קבצים.
- לא להוסיף טקסט לתמונות.
- לא לשנות DB.
- לא לשנות כלכלת מטבעות.
- לא לשנות לוגיקת הישגים.
- רק לחבר את התמונות לקלפי ההישג המתאימים.
