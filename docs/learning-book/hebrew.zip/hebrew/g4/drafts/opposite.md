# מילים הפוכות (כיתה ד׳)

## Metadata

| Field | Value |
|-------|-------|
| **learning_page_id** | `hebrew:g4:opposite` |
| **skill_id** | `hebrew:rich:vocabulary:antonym:opposite` |
| **subject** | hebrew |
| **grade** | g4 |
| **age_band** | grades_3_4 |
| **page_type** | concept_foundation |
| **approval_status** | draft |
| **title_hebrew** | מילים הפוכות (כיתה ד׳) `[DRAFT — not owner-approved]` |

**Source references:**
- `data/curriculum-spine/v1/skills.json`
- `docs/learning-book/HEBREW_LEARNING_BOOK_MASTER_SCOPE_PLAN.md`
- `docs/learning-book/MATH_LEARNING_PAGE_TEMPLATE.md`

**Rich band (G3–4):** G4 depth — do not reuse G3 page text.

**Content scope:** ניגודים; G4 depth

---

## 1. מה לומדים?

היום נלמד מילים הפוכות במשמעות — ניגוד.
ניגוד עוזר להבין טוב יותר את המילה.

---

## 2. הסבר

דוגמאות:
גבוה — נמוך
חם — קר
שקט — רועש

בקטע — מצאו מילה וההפך שלה.

---

## 3. דוגמה

קטע:
בבוקר הספרייה הייתה שקטה. אחרי הצלצול, החדר התמלא רעש וצחוק — ההפך משקט.

שקט — רועש: ניגוד ברור.

---

## 4. בואו נפתור

שאלה: קראו קטע על שמורה.

בשביל הצר מצאנו צל וקרירות. על הראש הייתה שמש חזקה וחום.

איזו מילה הפוכה ל«קרירות»?

תשובה: חום.

---

## 5. נסו בעצמכם

קראו:
הכתבה מתארת ים שקט בבוקר וסערה אחר הצהריים — ים ___ . (שקט / נוח / רגוע מול סוער)

מה ההפך של שקט בים?

(רמז: הפך — מילה עם משמעות נגדית.)

---

## 6. שימו לב!

קל לטעות: לבחור מילה שלא באמת הפוכה — רק שונה קצת.

❌ «ים» ו«חוף» — לא הפוכים.

✓ שקט וסוער — הפך במשמעות.

זכרו: הפך — משמעות נגדית ברורה.

---

## 7. בואו נתרגל!

עכשיו אתם מוצאים מילים הפוכות בקטע ובמשפט.
בתרגול תזוג ניגודים נכון.
