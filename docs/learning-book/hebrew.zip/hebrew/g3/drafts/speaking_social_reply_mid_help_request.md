# בקשת עזרה בנימוס

## Metadata

| Field | Value |
|-------|-------|
| **learning_page_id** | `hebrew:g3:speaking_social_reply_mid_help_request` |
| **skill_id** | `hebrew:rich:speaking:social_reply_mid_help:request` |
| **subject** | hebrew |
| **grade** | g3 |
| **age_band** | grades_3_4 |
| **page_type** | concept_foundation |
| **approval_status** | draft |
| **title_hebrew** | בקשת עזרה בנימוס `[DRAFT — not owner-approved]` |

**Source references:**
- `data/curriculum-spine/v1/skills.json`
- `docs/learning-book/HEBREW_LEARNING_BOOK_MASTER_SCOPE_PLAN.md`
- `docs/learning-book/HEBREW_GRADE_3_LEARNING_BOOK_PLAN.md`
- `docs/learning-book/MATH_LEARNING_PAGE_TEMPLATE.md`

**Content scope:** אפשר בבקשה? עזרה; תגובה חברתית

---

## 1. מה לומדים?

היום נלמד בעברית לבקש עזרה בנימוס ולענות לחבר.
אפשר בבקשה, תודה — מילים חשובות בשיחה.
גם כשצריך עזרה — אפשר לדבר יפה.

---

## 2. הסבר

בקשה: אפשר בבקשה עזרה בשאלה?
תגובה נעימה: בטח, בשמחה.
אחרי עזרה: תודה רבה.
שיחה קצרה — לא צריך הרבה מילים.

---

## 3. דוגמה

תלמיד: מורה, אפשר בבקשה עזרה? לא הבנתי את התרגיל.
מורה: כן, בוא נסביר יחד.
תלמיד: תודה.

---

## 4. בואו נפתור

שאלה: איך מבקשים עזרה בנימוס?

שלב 1: מתחילים בבקשה — אפשר בבקשה.

שלב 2: אומרים מה צריך — עזרה.

שלב 3: אחר כך תודה.

תשובה: אפשר בבקשה, עזרה.

---

## 5. נסו בעצמכם

חבר לא מבין את השאלה. מה יגיד — עזרה, בבקשה, או רק תודה לפני הבקשה?

(רמז: קודם מבקשים, אחר כך מודים.)

---

## 6. שימו לב!

קל לטעות: לצעוק עזרה בלי בבקשה.

❌ תעזור לי עכשיו — חד — פחות מנומס.

✓ עזרה, בבקשה — בקשה נכונה. תודה — אחרי.

זכרו: בבקשה לפני בקשה. תודה אחרי.

---

## 7. בואו נתרגל!

עכשיו אתם יודעים לבקש עזרה ולענות בנימוס בעברית.
בתרגול תמצאו מצבים עם עזרה ובבקשה. דברו בעדינות!

---
