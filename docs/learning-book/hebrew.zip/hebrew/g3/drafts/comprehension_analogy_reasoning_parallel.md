# דומה כמו...

## Metadata

| Field | Value |
|-------|-------|
| **learning_page_id** | `hebrew:g3:comprehension_analogy_reasoning_parallel` |
| **skill_id** | `hebrew:rich:comprehension:analogy_reasoning:parallel` |
| **subject** | hebrew |
| **grade** | g3 |
| **age_band** | grades_3_4 |
| **page_type** | mixed |
| **approval_status** | draft |
| **title_hebrew** | דומה כמו... `[DRAFT — not owner-approved]` |

**Source references:**
- `data/curriculum-spine/v1/skills.json`
- `docs/learning-book/HEBREW_LEARNING_BOOK_MASTER_SCOPE_PLAN.md`
- `docs/learning-book/HEBREW_GRADE_3_LEARNING_BOOK_PLAN.md`
- `docs/learning-book/MATH_LEARNING_PAGE_TEMPLATE.md`

**Content scope:** יחס דמיון פשוט בין זוגות מילים

---

## 1. מה לומדים?

היום נלמד בעברית על דמיון בין זוגות מילים.
כמו... — אותו סוג של קשר.
זה חידה של מילים, לא סיפור ארוך.

---

## 2. הסבר

באנלוגיה בודקים איך שני דברים קשורים, ואז מוצאים זוג דומה.
חם קשור לקיץ כמו קר קשור לחורף.
הקשר דומה — לא בהכרח אותה מילה.

---

## 3. דוגמה

חם : קיץ :: קר : ?
הקיץ הוא עונה חמה — החורף עונה קרה.
תשובה: חורף.

---

## 4. בואו נפתור

שאלה: למה קיץ מתאים לחם?

שלב 1: חם — מזג בקיץ.

שלב 2: קיץ — עונה.

שלב 3: אותו רעיון כמו קר וחורף.

תשובה: בקיץ בדרך כלל חם.

---

## 5. נסו בעצמכם

חם : קיץ :: קר : ?
האם התשובה חורף או שולחן?

(רמז: חם וקיץ ביחד — מה מתאים לקר?)

---

## 6. שימו לב!

קל לטעות: לבחור מילה שנשמעת יפה בלי לבדוק את הקשר.

❌ חם : שולחן — לא! אין קשר כמו קיץ.

✓ חם : קיץ — אותו סוג קשר כמו קר לחורף.

זכרו: שואלים — במה הזוג הראשון דומה?

---

## 7. בואו נתרגל!

עכשיו אתם יודעים לחשוב על זוגות דומים בעברית.
בתרגול תמצאו חידות כמו חם וקיץ. בדקו את הקשר!

---
