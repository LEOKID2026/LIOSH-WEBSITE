# ביטוי מנומס בכתיבה

## Metadata

| Field | Value |
|-------|-------|
| **learning_page_id** | `hebrew:g3:writing_structured_completion_polite_phrase` |
| **skill_id** | `hebrew:rich:writing:structured_completion:polite_phrase` |
| **subject** | hebrew |
| **grade** | g3 |
| **age_band** | grades_3_4 |
| **page_type** | mixed |
| **approval_status** | draft |
| **title_hebrew** | ביטוי מנומס בכתיבה `[DRAFT — not owner-approved]` |

**Source references:**
- `data/curriculum-spine/v1/skills.json`
- `docs/learning-book/HEBREW_LEARNING_BOOK_MASTER_SCOPE_PLAN.md`
- `docs/learning-book/HEBREW_GRADE_3_LEARNING_BOOK_PLAN.md`
- `docs/learning-book/MATH_LEARNING_PAGE_TEMPLATE.md`

**Content scope:** השלמת ביטוח מנומס במשפט

---

## 1. מה לומדים?

היום נלמד בעברית להשלים ביטוי מנומס בכתיבה.
בבקשה, תודה, סליחה — עושים משפט נעים.
מתאים למכתב קצר או הודעה לחבר.

---

## 2. הסבר

בקשה מתחילה בנימוס: אפשר בבקשה לעזור?
תודה באה אחרי טובה: עזרת לי, תודה.
המשפט נשמע מכובד כשמוסיפים ביטוי מנומס.

---

## 3. דוגמה

טיוטה: שלום, אמא. האם אפשר ___ לצאת לחבר?
השלמה: בבקשה.
משפט מלא: האם אפשר בבקשה לצאת לחבר?

---

## 4. בואו נפתור

שאלה: מה חסר — בבקשה או תודה?

שלב 1: זו בקשה — שואלים רשות.

שלב 2: לפני בקשה — בבקשה.

שלב 3: תודה — אחרי עזרה.

תשובה: בבקשה (כאן).

---

## 5. נסו בעצמכם

משפט: תודה על העזרה, ועוד פעם ___. מה מתאים להשלים — תודה או בבקשה לפני הבקשה הבאה?

(רמז: כבר אמרתם תודה — איזה ביטוי חוזר על נימוס?)

---

## 6. שימו לב!

קל לטעות: לשכוח נימוס במכתב קצר.

❌ תן לי — בלי בבקשה — פחות מנומס.

✓ בבקשה, תודה — משפט מנומס.

זכרו: בקשה — בבקשה. אחרי עזרה — תודה.

---

## 7. בואו נתרגל!

עכשיו אתם יודעים להשתמש בביטויים מנומסים בכתיבה בעברית.
בתרגול תמצאו משפטים עם בבקשה ותודה. השלימו בנימוס!

---
