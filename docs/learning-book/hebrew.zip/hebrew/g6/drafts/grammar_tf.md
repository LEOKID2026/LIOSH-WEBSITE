# נכון או לא — דקדוק (כיתה ו׳)

## Metadata

| Field | Value |
|-------|-------|
| **learning_page_id** | `hebrew:g6:grammar_tf` |
| **skill_id** | `hebrew:rich:grammar:binary_grammar:tf` |
| **subject** | hebrew |
| **grade** | g6 |
| **age_band** | grades_5_6 |
| **page_type** | practice_bridge |
| **approval_status** | draft |
| **title_hebrew** | נכון או לא — דקדוק (כיתה ו׳) `[DRAFT — not owner-approved]` |

**Source references:**
- `data/curriculum-spine/v1/skills.json`
- `docs/learning-book/HEBREW_LEARNING_BOOK_MASTER_SCOPE_PLAN.md`
- `docs/learning-book/MATH_LEARNING_PAGE_TEMPLATE.md`

**Rich band (G5–6):** G6 depth — do not reuse G5 page text.

**Content scope:** שיפוט דקדוקי; G6 depth

---

## 1. מה לומדים?

היום נלמד לשפוט — האם משפט נכון דקדוקית.
נכון או לא — בודקים נושא, פועל ומילים.

---

## 2. הסבר

שאלות לבדיקה:

האם הנושא והפועל מתאימים?
האם «של» במקום הנכון?
האם המשפט «נשמע» נכון?

אם יש ספק — קראו בקול.

---

## 3. דוגמה

«הכלבים רץ» — לא נכון. כלבים (רבים) → רצים.
«הספר שלי על השולחן» — נכון.

---

## 4. בואו נפתור

שאלה: האם נכון?

«התלמידות כותבות עבודה».

שלב 1: נושא — תלמידות (רבים).

שלב 2: כותבות — מתאים.

תשובה: נכון.

---

## 5. נסו בעצמכם

קראו:
«הספרים על המדף נמצא».

האם המשפט נכון דקדוקית?

(רמז: נכון — בודקים דקדוק; לא — מוצאים שגיאה.)

---

## 6. שימו לב!

קל לטעות: לומר «נכון» — כי «מבין» — בלי לבדוק רבים.

❌ «ספרים... נמצא» — לא נכון.

✓ דקדוק — «נמצאים» ל«ספרים» — נכון.

זכרו: נכון או לא — תמיד בודקים נושא ופועל.

---

## 7. בואו נתרגל!

עכשיו אתם יודעים לשפוט אם משפט נכון דקדוקית.
בתרגול תחליטו נכון או לא.
