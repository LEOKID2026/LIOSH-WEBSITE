# מי שונה בקבוצה? (כיתה ו׳)

## Metadata

| Field | Value |
|-------|-------|
| **learning_page_id** | `hebrew:g6:odd_out` |
| **skill_id** | `hebrew:rich:vocabulary:category_exclusion:odd_out` |
| **subject** | hebrew |
| **grade** | g6 |
| **age_band** | grades_5_6 |
| **page_type** | concept_foundation |
| **approval_status** | draft |
| **title_hebrew** | מי שונה בקבוצה? (כיתה ו׳) `[DRAFT — not owner-approved]` |

**Source references:**
- `data/curriculum-spine/v1/skills.json`
- `docs/learning-book/HEBREW_LEARNING_BOOK_MASTER_SCOPE_PLAN.md`
- `docs/learning-book/MATH_LEARNING_PAGE_TEMPLATE.md`

**Rich band (G5–6):** G6 depth — do not reuse G5 page text.

**Content scope:** קטגוריות; G6 depth

---

## 1. מה לומדים?

היום נלמד למצוא מי שונה בקבוצה — מילה שלא שייכת לאחרים.
כל הקבוצה — קטגוריה אחת; אחת — שונה.

---

## 2. הסבר

שיטה:

קראו את כל המילים.
מה משותף לרוב?
איזו לא מתאימה?

דוגמה: ספר, מחברת, עט, כלב — כלב שונה (לא כלי כתיבה).

---

## 3. דוגמה

קבוצה: ניסוי, מדידה, תצפית, סיפור.
סיפור — לא מדע (שאר המילים — מדע).

---

## 4. בואו נפתור

שאלה: מי שונה?

א: ספר
ב: מחברת
ג: עט
ד: כלב

שלב 1: שלושה — כלי כתיבה/לימוד.

שלב 2: כלב — לא באותה קבוצה.

תשובה: ד.

---

## 5. נסו בעצמכם

קראו:
ניתוח, השוואה, סיכום, כדורגל.

איזו מילה שונה בקבוצה? למה?

(רמז: שונה — לא שייך; קבוצה — מה משותף?)

---

## 6. שימו לב!

קל לטעות: לבחור «סיכום» — כי ארוך — בלי לבדוק קטגוריה.

❌ לפי אורך — לא לפי משמעות.

✓ שונה בקבוצה — כדורגל לא מונח למידה; השאר — מונחי עבודה.

זכרו: מי שונה — לפי קטגוריה, לא לפי טעם.

---

## 7. בואו נתרגל!

עכשיו אתם יודעים למצוא מי שונה בקבוצה.
בתרגול תבחרו את המילה שלא שייכת.
