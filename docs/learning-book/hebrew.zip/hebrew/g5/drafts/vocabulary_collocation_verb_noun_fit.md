# צירוף נכון

## Metadata

| Field | Value |
|-------|-------|
| **learning_page_id** | `hebrew:g5:vocabulary_collocation_verb_noun_fit` |
| **skill_id** | `hebrew:rich:vocabulary:collocation:verb_noun_fit` |
| **subject** | hebrew |
| **grade** | g5 |
| **age_band** | grades_5_6 |
| **page_type** | practice_bridge |
| **approval_status** | draft |
| **title_hebrew** | צירוף נכון `[DRAFT — not owner-approved]` |

**Source references:**
- `data/curriculum-spine/v1/skills.json`
- `docs/learning-book/HEBREW_LEARNING_BOOK_MASTER_SCOPE_PLAN.md`
- `docs/learning-book/HEBREW_GRADE_5_LEARNING_BOOK_PLAN.md`
- `docs/learning-book/MATH_LEARNING_PAGE_TEMPLATE.md`

**Content scope:** פועל + שם עצם שמתחברים

---

## 1. מה לומדים?

היום נתרגל בעברית צירוף נכון של פועל ושם עצם.
יש צירופים שמתחברים בשפה: שמר סוד, שבר שתיקה.
לא כל פועל מתאים לכל שם.

---

## 2. הסבר

שואלים: האם זה נשמע טבעי בעברית?
שמר סוד — כן. שמר כיסא — מוזר.
לומדים צירופים נפוצים מקריאה וכתיבה.

---

## 3. דוגמה

נכון: הוא שמר סוד והבטיח לא לספר.
לא נכון: הוא שמר כיסא (במשמעות סוד).
הפועל שמר מתאים לסוד, לא לרהיט.

---

## 4. בואו נפתור

שאלה: מה מתאים — שמר ___?

שלב 1: שמר עם סוד — מוכר.

שלב 2: שמר עם שולחן — לא צירוף.

תשובה: שמר סוד.

---

## 5. נסו בעצמכם

בחרו: א) שבר שתיקה. ב) שבר מחשבה. ג) שבר סוד.
איזה צירוף נכון בעברית?

(רמז: שמר סוד — פועל ושם שמתחברים.)

---

## 6. שימו לב!

קל לטעות: לתרגם מילה במילה מאנגלית.

❌ עשה בית ספר — במקום למד בבית ספר — לא צירוף עברי!

✓ למד בבית ספר, שמר סוד.

זכרו: צירוף — מה שנשמע נכון יחד.

---

## 7. בואו נתרגל!

עכשיו אתם יודעים לזהות צירוף נכון של פועל ושם עצם.
בתרגול תמצאו זוגות כמו שמר וסוד. בחרו מה מתחבר!

---
