# פעולות — Present Simple

## Metadata

| Field | Value |
|-------|-------|
| **learning_page_id** | `english:g3:vocab_actions` |
| **skill_id** | `english:vocabulary:wordlist:actions` |
| **subject** | english |
| **grade** | g3 |
| **age_band** | grades_3_4 |
| **page_type** | vocabulary_theme |
| **approval_status** | draft |
| **title_hebrew** | פעולות — Present Simple `[DRAFT — not owner-approved]` |

**Source references:**
- `data/curriculum-spine/v1/skills.json`
- `docs/learning-book/ENGLISH_LEARNING_BOOK_MASTER_SCOPE_PLAN.md`

**Content scope:** פועל בזמן הווה פשוט; actions בשנה אחרונה

---

## 1. מה לומדים?

היום נלמד פעולות באנגלית בזמן הווה פשוט.
כבר מכירים run ו-play — נחבר אותם במשפטים מלאים.

---

## 2. הסבר

בזמן הווה פשוט משתמשים בפועל הבסיסי:

I play.

אני משחק.

He runs.

הוא רץ.

---

## 3. דוגמה

ילד משחק בכדור.

I play.

אני משחק.

---

## 4. בואו נפתור

שאלה: איך אומרים "אני משחק"?

I play

תשובה: I play

---

## 5. נסו בעצמכם

ילד משחק בחצר.

I play

(רמז: play = לשחק.)

---

## 6. שימו לב!

play ו-run — פעולות שונות.

❌ I run כשמשחקים!

✓ I play.

I play = אני משחק.

---

## 7. בואו נתרגל!

עכשיו אתם בונים משפטים עם פעולות בזמן הווה פשוט.
בתרגול תמצאו I play ו-He runs.
