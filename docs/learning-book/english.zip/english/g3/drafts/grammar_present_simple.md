# Present Simple — חיובי, שלילי ושאלה

## Metadata

| Field | Value |
|-------|-------|
| **learning_page_id** | `english:g3:grammar_present_simple` |
| **skill_id** | `english:pool:grammar:present_simple` |
| **subject** | english |
| **grade** | g3 |
| **age_band** | grades_3_4 |
| **page_type** | step_by_step_procedure |
| **approval_status** | draft |
| **title_hebrew** | Present Simple — חיובי, שלילי ושאלה `[DRAFT — not owner-approved]` |

**Source references:**
- `data/curriculum-spine/v1/skills.json`
- `docs/learning-book/ENGLISH_LEARNING_BOOK_MASTER_SCOPE_PLAN.md`

**Linked skill_ids:** `english:grammar:line:present_simple_בחיובי_שלילי_שאלה`

**Content scope:** I play / I do not play / Do you play? — הסבר בעברית פשוטה

---

## 1. מה לומדים?

היום נלמד Present Simple — זמן הווה פשוט.
חיובי, שלילי ושאלה.

---

## 2. הסבר

חיובי:
I play tennis.

שלילי:
I do not play tennis.

שאלה:
Do you play tennis?

---

## 3. דוגמה

ילד משחק טניס.

I play tennis.

אני משחק טניס.

---

## 4. בואו נפתור

שאלה: איך אומרים "אני משחק טניס"?

I play tennis

תשובה: I play tennis

---

## 5. נסו בעצמכם

מגרש טניס.

I play tennis

(רמז: play tennis = משחק טניס.)

---

## 6. שימו לב!

I plays tennis — שגוי!

❌ I plays — I לא מקבל s!

✓ I play tennis.

He plays — הוא כן מקבל s.

---

## 7. בואו נתרגל!

עכשיו אתם יודעים Present Simple — חיובי, שלילי ושאלה.
בתרגול תמצאו I play tennis ו-Do you play?
