# שגרת יום — משפטים

## Metadata

| Field | Value |
|-------|-------|
| **learning_page_id** | `english:g2:sentence_routine` |
| **skill_id** | `english:pool:sentence:routine` |
| **subject** | english |
| **grade** | g2 |
| **age_band** | grades_1_2 |
| **page_type** | visual_intuition |
| **approval_status** | draft |
| **title_hebrew** | שגרת יום — משפטים `[DRAFT — not owner-approved]` |

**Source references:**
- `data/curriculum-spine/v1/skills.json`
- `docs/learning-book/ENGLISH_GRADE_2_LEARNING_BOOK_PLAN.md`
- `docs/learning-book/ENGLISH_LEARNING_BOOK_MASTER_SCOPE_PLAN.md`

**Content scope:** I wake up / I go to school — שגרה יומית

---

## 1. מה לומדים?

היום נלמד משפטים על שגרת יום.
מה עושים בבוקר — באנגלית.

---

## 2. הסבר

משפטי שגרה:

I wake up.

אני מתעורר.

I go to school.

אני הולך לבית ספר.

---

## 3. דוגמה

בוקר. קמים מהמיטה.

I wake up.

אני מתעורר.

---

## 4. בואו נפתור

שאלה: איך אומרים "אני מתעורר"?

I wake up

תשובה: I wake up

---

## 5. נסו בעצמכם

בוקר. ילד קם.

I wake up

(רמז: מתעורר = wake up.)

---

## 6. שימו לב!

wake up ו-go to school — שני שלבים.

❌ I go to school כשקמים מהמיטה!

✓ I wake up.

קודם I wake up.

---

## 7. בואו נתרגל!

עכשיו אתם מכירים משפטי שגרה.
בתרגול תמצאו I wake up ו-I go to school.
