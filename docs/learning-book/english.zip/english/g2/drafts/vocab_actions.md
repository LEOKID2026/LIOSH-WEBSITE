# פעולות — פועל במשפט

## Metadata

| Field | Value |
|-------|-------|
| **learning_page_id** | `english:g2:vocab_actions` |
| **skill_id** | `english:vocabulary:wordlist:actions` |
| **subject** | english |
| **grade** | g2 |
| **age_band** | grades_1_2 |
| **page_type** | vocabulary_theme |
| **approval_status** | draft |
| **title_hebrew** | פעולות — פועל במשפט `[DRAFT — not owner-approved]` |

**Source references:**
- `data/curriculum-spine/v1/skills.json`
- `docs/learning-book/ENGLISH_GRADE_2_LEARNING_BOOK_PLAN.md`
- `docs/learning-book/ENGLISH_LEARNING_BOOK_MASTER_SCOPE_PLAN.md`

**Content scope:** I run / I jump

---

## 1. מה לומדים?

היום נשתמש בפועל במשפט.
כבר מכירים run ו-jump — נחבר עם I.

---

## 2. הסבר

תבנית:

I run.

אני רץ.

I jump.

אני קופץ.

---

## 3. דוגמה

ילד קופץ.

I jump.

אני קופץ.

---

## 4. בואו נפתור

שאלה: איך אומרים "אני קופץ"?

I jump

תשובה: I jump

---

## 5. נסו בעצמכם

ילד קופץ גבוה.

I jump

(רמז: jump = לקפוץ.)

---

## 6. שימו לב!

run ו-jump — פעולות שונות.

❌ I run כשקופצים!

✓ I jump.

jump = לקפוץ.

---

## 7. בואו נתרגל!

עכשיו אתם בונים משפטים עם פעולות.
בתרגול תמצאו I run ו-I jump.
