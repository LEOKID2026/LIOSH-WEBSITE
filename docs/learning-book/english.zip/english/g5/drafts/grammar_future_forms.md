# Future — will / going to

## Metadata

| Field | Value |
|-------|-------|
| **learning_page_id** | `english:g5:grammar_future_forms` |
| **skill_id** | `english:pool:grammar:future_forms` |
| **subject** | english |
| **grade** | g5 |
| **age_band** | grades_5_6 |
| **page_type** | concept_foundation |
| **approval_status** | draft |
| **title_hebrew** | Future — will / going to `[DRAFT — not owner-approved]` |

**Source references:**
- `data/curriculum-spine/v1/skills.json`
- `docs/learning-book/ENGLISH_LEARNING_BOOK_MASTER_SCOPE_PLAN.md`

**Linked skill_ids:** `english:grammar:line:מודאליים_בסיסיים_future_will_going_to_והשוואתיים`

**Content scope:** I will call you / We are going to visit

---

## 1. מה לומדים?

היום נלמד Future — will ו-going to.
We are going to visit grandma — אנחנו הולכים לבקר את סבתא.

---

## 2. הסבר

will — החלטה או הבטחה:
I will call you.

אני אתקשר אליך.

going to — תוכנית:
We are going to visit grandma.

אנחנו הולכים לבקר את סבתא.

---

## 3. דוגמה

סוף שבוע — ביקור אצל סבתא.

We are going to visit grandma.

אנחנו הולכים לבקר את סבתא.

---

## 4. בואו נפתור

שאלה: איך אומרים "אנחנו הולכים לבקר את סבתא"?

We are going to visit grandma

תשובה: We are going to visit grandma

---

## 5. נסו בעצמכם

תוכנית לסוף השבוע — סבתא.

We are going to visit grandma

(רמז: going to = תוכנית.)

---

## 6. שימו לב!

We will going to visit grandma — שגוי!

❌ will + going to — לא יחד!

✓ We are going to visit grandma.

going to = תוכנית קרובה.

---

## 7. בואו נתרגל!

עכשיו אתם בוחרים will או going to לעתיד.
בתרגול תמצאו We are going to visit grandma.
