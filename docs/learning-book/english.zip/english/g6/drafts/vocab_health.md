# בריאות — should rest

## Metadata

| Field | Value |
|-------|-------|
| **learning_page_id** | `english:g6:vocab_health` |
| **skill_id** | `english:vocabulary:wordlist:health` |
| **subject** | english |
| **grade** | g6 |
| **age_band** | grades_5_6 |
| **page_type** | vocabulary_theme |
| **approval_status** | draft |
| **title_hebrew** | בריאות — should rest `[DRAFT — not owner-approved]` |

**Source references:**
- `data/curriculum-spine/v1/skills.json`
- `docs/learning-book/ENGLISH_LEARNING_BOOK_MASTER_SCOPE_PLAN.md`

**Content scope:** You should drink water — עצות בריאות

---

## 1. מה לומדים?

היום נחזק בריאות עם should — עצה.
You should drink water and rest when you are tired — כדאי לשתות מים ולנוח כשאתם עייפים.

---

## 2. הסבר

should + פועל — כדאי / מומלץ:

You should drink water and rest when you are tired.

כדאי לשתות מים ולנוח כשאתם עייפים.

You should sleep eight hours every night.

כדאי לישון שמונה שעות בכל לילה.

---

## 3. דוגמה

אחרי יום ארוך בבית הספר.

You should drink water and rest when you are tired.

כדאי לשתות מים ולנוח כשאתם עייפים.

---

## 4. בואו נפתור

שאלה: איך אומרים "כדאי לשתות מים ולנוח כשאתם עייפים"?

You should drink water and rest when you are tired

תשובה: You should drink water and rest when you are tired

---

## 5. נסו בעצמכם

אחרי אימון — מה כדאי לעשות?

You should drink water and rest when you are tired

(רמז: should = כדאי.)

---

## 6. שימו לב!

You should to drink water and rest — שגוי!

❌ should + to — לא נכון!

✓ You should drink water and rest when you are tired.

should + פועל (בלי to).

---

## 7. בואו נתרגל!

עכשיו אתם נותנים עצות בריאות עם should.
בתרגול תמצאו You should drink water and rest when you are tired.
