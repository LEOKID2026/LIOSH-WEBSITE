# קהילה — festival, celebrate

## Metadata

| Field | Value |
|-------|-------|
| **learning_page_id** | `english:g6:vocab_community` |
| **skill_id** | `english:vocabulary:wordlist:community` |
| **subject** | english |
| **grade** | g6 |
| **age_band** | grades_5_6 |
| **page_type** | vocabulary_theme |
| **approval_status** | draft |
| **title_hebrew** | קהילה — festival, celebrate `[DRAFT — not owner-approved]` |

**Source references:**
- `data/curriculum-spine/v1/skills.json`
- `docs/learning-book/ENGLISH_LEARNING_BOOK_MASTER_SCOPE_PLAN.md`

**Content scope:** Our community celebrated — אירועים בקהילה

---

## 1. מה לומדים?

היום נחזק אוצר מילים על קהילה — festival, celebrate.
Our community celebrated the festival last month — הקהילה שלנו חגגה את הפסטיבל בחודש שעבר.

---

## 2. הסבר

celebrate — לחגוג; festival — פסטיבל:

Our community celebrated the festival last month.

הקהילה שלנו חגגה את הפסטיבל בחודש שעבר.

Many families joined the parade.

משפחות רבות הצטרפו למצעד.

---

## 3. דוגמה

פסטיבל רחוב בקהילה.

Our community celebrated the festival last month.

הקהילה שלנו חגגה את הפסטיבל בחודש שעבר.

---

## 4. בואו נפתור

שאלה: איך אומרים "הקהילה שלנו חגגה את הפסטיבל בחודש שעבר"?

Our community celebrated the festival last month

תשובה: Our community celebrated the festival last month

---

## 5. נסו בעצמכם

אירוע קהילתי — כולם יחד.

Our community celebrated the festival last month

(רמז: celebrated = חגגה בעבר.)

---

## 6. שימו לב!

Our community celebrate the festival last month — שגוי!

❌ celebrate — Present Simple!

✓ Our community celebrated the festival last month.

celebrated = חגגה (Past Simple).

---

## 7. בואו נתרגל!

עכשיו אתם מתארים אירועים בקהילה.
בתרגול תמצאו Our community celebrated the festival last month.
