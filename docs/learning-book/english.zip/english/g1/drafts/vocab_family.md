# משפחה באנגלית

## Metadata

| Field | Value |
|-------|-------|
| **learning_page_id** | `english:g1:vocab_family` |
| **skill_id** | `english:vocabulary:wordlist:family` |
| **subject** | english |
| **grade** | g1 |
| **age_band** | grades_1_2 |
| **page_type** | vocabulary_theme |
| **approval_status** | draft |
| **title_hebrew** | משפחה באנגלית `[DRAFT — not owner-approved]` |

**Source references:**
- `data/curriculum-spine/v1/skills.json`
- `docs/learning-book/ENGLISH_GRADE_1_LEARNING_BOOK_PLAN.md`
- `docs/learning-book/ENGLISH_LEARNING_BOOK_MASTER_SCOPE_PLAN.md`

**Content scope:** mom, dad, sister, brother — מילים בסיסיות

---

## 1. מה לומדים?

היום נלמד מילים באנגלית לבני משפחה.
כולנו חלק ממשפחה — ויש לה שמות באנגלית.

---

## 2. הסבר

מילים בסיסיות:

mom — אמא
dad — אבא
sister — אחות
brother — אח

---

## 3. דוגמה

אמא שלי בבית.
באנגלית:

mom

אמא = mom.

---

## 4. בואו נפתור

שאלה: מה המילה לאבא באנגלית?

שלב 1: חושבים על אבא.
שלב 2:

dad

תשובה: dad

---

## 5. נסו בעצמכם

מי האישה במשפחה שאנחנו קוראים לה אמא?

המילה באנגלית:

mom

(רמז: אמא = mom.)

---

## 6. שימו לב!

קל לבלבל בין מילים דומות.

❌ לקרוא לאמא dad — זה אבא!

✓ אמא = mom.

זכרו: mom לאבא לא מתאים.

---

## 7. בואו נתרגל!

עכשיו אתם מכירים מילים למשפחה באנגלית.
בתרגול תמצאו שאלות על mom, dad, sister ו-brother.
