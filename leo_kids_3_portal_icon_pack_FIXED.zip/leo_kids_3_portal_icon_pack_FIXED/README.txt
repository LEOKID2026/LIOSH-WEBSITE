LEO KIDS - 3 Portal Icon Pack - FIXED

גרסה מתוקנת:
- הילד כבר לא חתוך בצדדים/בפינות.
- המורה כבר לא חתוך ולא כולל חיתוך לא תקין.
- ההורה נשמר באותו סגנון, עם crop נקי יותר כדי שכל הסט יהיה אחיד.

כולל 3 תיקיות:
- child   = ילד
- parent  = הורה
- teacher = מורה

בכל תיקייה יש:
- favicon.ico
- favicon PNG: 16, 24, 32, 48
- Android / PWA: 72, 96, 128, 144, 152, 192, 384, 512
- iOS / Apple Touch: 57, 60, 72, 76, 114, 120, 144, 152, 167, 180
- Windows tiles: 70, 150, 310, 310x150
- Maskable icons: 192, 384, 512, 1024
- manifest-icons.json
- html-head-snippet.txt

המלצת נתיבים:
public/icons/child/
public/icons/parent/
public/icons/teacher/
