# Hebrew Copy Delta Summary

Generated: 2026-05-29T20:23:33.997Z

## Gate result

| Metric | Value |
|--------|------:|
| Baseline version | v1.0.1 |
| Scan mode | hybrid |
| Baseline files scanned | 346 |
| New files discovered | 150 |
| Baseline records | 77340 |
| Files scanned | 496 |
| Current strings | 50198 |
| **Delta count** | **0** |
| Gate pass | yes |
| Critical new/changed | 0 |
| Medium new/changed | 0 |
| Unreviewed critical introduced | no |

## By change type

- (none)

## By risk level

- (none)

## Top critical deltas (first 15)

- (none)

> Baseline is known-current-state only — not approval. Review workbook: `reports/hebrew-copy-delta-review.xlsx`
