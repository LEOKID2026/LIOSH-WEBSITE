# Hebrew Copy Delta Noise Analysis

Generated: 2026-05-29T20:24:36.358Z

Initial snapshot source: `C:\Users\ERAN YOSEF\Desktop\final projects\FINAL-WEB\LIOSH-WEB-TRY\review-packages\hebrew-copy-delta-gate-review\reports\hebrew-copy-delta-summary.json`

## Initial 352-delta dry-run (before noise reduction)

| Metric | Count |
|--------|------:|
| Total deltas | 352 |
| new (+ template) | 274 |
| changed | 2 |
| moved | 76 |
| removed | 0 |
| critical | 305 |
| internal | 26 |

### Category summary

| Category | Count | Meaning |
|----------|------:|---------|
| Scanner / alignment noise | 350 | Safe to reduce automatically with documented scanner rules |
| True new/changed Hebrew | 2 | Must not be auto-suppressed |
| Unclear / needs review | 0 | Manual triage |

### Bucket breakdown (all root-cause buckets)

| Bucket | Count | Auto-safe | Category | Recommended fix |
|--------|------:|:---------:|----------|-----------------|
| Archive/internal/test/log strings (internal_only) | 127 | yes | scanner_alignment_noise | Classify forbidden-terms, guard, selftest, scripts/tests as internal; suppress orphan unmatched. |
| Scan-root mismatch versus baseline inventory | 78 | yes | scanner_alignment_noise | Use baseline-aligned file scan; exclude inventory-denied paths (help-center parent-report, student worksheet). |
| Moved-only / line shift | 76 | yes | scanner_alignment_noise | Suppress moved deltas when text_hash matches baseline (suppressMovedOnly default true). |
| Multi-string line extraction mismatch | 54 | no | scanner_alignment_noise | Improve per-line extraction to match inventory row granularity; suppress partial replace-rule fragments. |
| Missing source_line / source anchor from inventory | 14 | no | scanner_alignment_noise | Prefer text_hash match over file:line anchor; rebuild baseline with corrected line metadata. |
| True changed Hebrew | 2 | no | true_hebrew_change | No auto-suppress — route to owner/expert review. |
| Template literal / template skeleton mismatch | 1 | no | scanner_alignment_noise | Align is_template detection between inventory sheets and scanner; compare skeleton hashes. |
| Escaping / quote normalization | 0 | yes | scanner_alignment_noise | Apply decodeJsStringLiteral in scan + baseline ingest; align hashes via normalizeTextForHash. |
| Whitespace / unicode / bidi normalization | 0 | yes | scanner_alignment_noise | NFC normalize, strip ZW chars, collapse whitespace in normalizeTextForHash. |
| True new Hebrew | 0 | no | true_hebrew_change | No auto-suppress — route to owner/expert review. |
| Unclear / needs review | 0 | no | unclear | Manual triage; extend classifier rules after review. |

### Top noisy source files (initial 352)

- `utils/parent-report-language/forbidden-terms.js` — 115
- `data/help-center/content/parent-report.js` — 103
- `utils/parent-copilot/question-classifier.js` — 36
- `utils/parent-copilot/conversational-reply-class-he.js` — 25
- `utils/detailed-report-parent-letter-he.js` — 18
- `utils/learning-patterns-analysis.js` — 11
- `utils/parent-report-language/parent-facing-normalize-he.js` — 10
- `pages/student/worksheet/[worksheetId].js` — 9
- `utils/parent-copilot/guardrail-validator.js` — 7
- `utils/parent-copilot/utterance-normalize-he.js` — 5
- `utils/parent-copilot/report-row-resolver.js` — 4
- `pages/learning/parent-report.js` — 2
- `utils/detailed-parent-report.js` — 2
- `utils/parent-copilot/scope-resolver.js` — 1
- `utils/parent-copilot/semantic-question-class.js` — 1

### Examples by bucket

#### Moved-only / line shift (76)

- **moved** `data/help-center/content/parent-report.js:18` — "סקירת דוח ההורים" (parent_report/student_visible)
- **moved** `data/help-center/content/parent-report.js:20` — "דוח" (parent_report/student_visible)
- **moved** `data/help-center/content/parent-report.js:20` — "סקירה" (parent_report/student_visible)

#### Template literal / template skeleton mismatch (1)

- **new_template** `pages/student/worksheet/[worksheetId].js:146` — " · מועד הגשה פיזית: ${new Date(worksheet.physicalDueAt).toLocaleString("he-IL")}" (site_general/student_visible)

#### Multi-string line extraction mismatch (54)

- **new** `pages/learning/parent-report.js:332` — "דפוס שגיאות" (parent_report/student_visible)
- **new** `pages/learning/parent-report.js:543` — "סיכום לפי שש המקצועות" (parent_report/internal_only)
- **new** `utils/detailed-parent-report.js:303` — "דגש על הנושא חיבור" (parent_report/internal_only)

#### Scan-root mismatch versus baseline inventory (78)

- **new** `data/help-center/content/parent-report.js:19` — "דוח מקוצר לעומת דוח מפורט — מתי משתמשים בכל אחד." (parent_report/student_visible)
- **new** `data/help-center/content/parent-report.js:22` — "דוח מקוצר" (parent_report/student_visible)
- **new** `data/help-center/content/parent-report.js:26` — "דוח מקוצר" (parent_report/student_visible)

#### Archive/internal/test/log strings (internal_only) (127)

- **new** `utils/parent-copilot/conversational-reply-class-he.js:241` — "ככה" (site_decision_ai/student_visible)
- **new** `utils/parent-copilot/conversational-reply-class-he.js:248` — "בטח" (site_decision_ai/student_visible)
- **new** `utils/parent-copilot/conversational-reply-class-he.js:259` — "אישור" (site_decision_ai/student_visible)

#### Missing source_line / source anchor from inventory (14)

- **new** `data/help-center/content/parent-report.js:30` — "דוח מפורט" (parent_report/student_visible)
- **new** `data/help-center/content/parent-report.js:41` — "כרטיס" (parent_report/student_visible)
- **new** `data/help-center/content/parent-report.js:163` — "דוח מפורט" (parent_report/student_visible)

#### True changed Hebrew (2)

- **changed** `utils/parent-copilot/conversational-reply-class-he.js:379` — "אז" (site_decision_ai/internal_only)
- **changed** `utils/parent-copilot/semantic-question-class.js:93` — "דוח" (site_decision_ai/student_visible)

## After noise reduction (v1.0.1 aligned scan)

| Metric | Before | After |
|--------|-------:|------:|
| delta_count | 352 | 0 |
| new | 274 | 0 |
| changed | 2 | 0 |
| moved | 76 | 0 |
| removed | 0 | 0 |
| critical | 305 | 0 |
| internal | 26 | 0 |

_No remaining deltas on unchanged workspace._
