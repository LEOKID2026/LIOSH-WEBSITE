# Hebrew Copy Delta Gate — Verification Notes (Hybrid Scan)

Generated: 2026-05-29

## Phase

Noise reduction + hybrid scan readiness for normal non-blocking site work.

## Blocking issue fixed

Baseline-only scan could not detect Hebrew in newly added files. Default is now **hybrid scan**: baseline file-index + new files under domain scan roots.

## Verification (all passed)

```
npm run hebrew:baseline
npm run hebrew:delta:smoke     → smoke 15/15, probe 7/7, e2e 4/4
npm run hebrew:delta:dry       → delta_count 0
node scripts/hebrew-copy-delta-gate.mjs --warn-only
npm run hebrew:delta:review    → 0 rows
node scripts/parent-report-hebrew-copy-guard.mjs
node scripts/hebrew-copy-delta-noise-analysis.mjs
```

## E2E proof (actual gate flow)

- Temp file under `components/learning/` → 1 `new` delta
- Temp parent-report file → `critical` / `pending_owner_review`
- Cleanup → 0 deltas

## Metrics

| | Before | After |
|---|-------:|------:|
| delta_count | 352 | 0 |

## Recommendation

**Ready** for normal non-blocking use.
