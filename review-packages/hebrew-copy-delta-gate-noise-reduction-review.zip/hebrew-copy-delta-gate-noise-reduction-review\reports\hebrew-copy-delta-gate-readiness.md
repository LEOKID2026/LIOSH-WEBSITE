# Hebrew Copy Delta Gate — Readiness Report (Noise-Reduction + Hybrid Scan)

Generated: 2026-05-29

## Final recommendation

**Ready** for normal non-blocking use (manual / dry-run / warn-only).

- Unchanged workspace: **0 deltas** (hybrid scan mode)
- New Hebrew-bearing files under scan roots: detected as `new` without baseline rebuild
- Smoke 15/15 · Probe 7/7 · E2E 4/4

---

## Blocking issue resolved: hybrid scan

**Problem:** Baseline-only scan missed Hebrew in new files until baseline rebuild.

**Fix:** Default `--scan-mode hybrid`:

| Layer | Behavior |
|-------|----------|
| Baseline file-index | Scanned with noise suppressions (moved-only, internal orphans, inventory noise) |
| New files under `DOMAIN_SCAN_ROOTS` | Auto-discovered; real visible Hebrew reported as `new` |
| Documented excludes | help-center parent-report, student worksheet, docs, review-packages |

Override: `--scan-mode baseline-only` (debug) · `--scan-mode broad` (noisy debug)

---

## Initial 352 deltas — root causes

| Bucket | Count | Auto-safe? |
|--------|------:|:----------:|
| Archive/internal/test/log | 127 | yes |
| Scan-root mismatch vs inventory | 78 | yes |
| Moved-only / line shift | 76 | yes |
| Multi-string extraction mismatch | 54 | partial |
| Missing source_line anchor | 14 | partial |
| Template skeleton mismatch | 1 | no |
| True changed Hebrew | 2 | **no** |

Top noisy files: `forbidden-terms.js` (115), `help-center/.../parent-report.js` (103), `question-classifier.js` (36).

Full analysis: [`hebrew-copy-delta-noise-analysis.md`](./hebrew-copy-delta-noise-analysis.md)

---

## Before / after metrics

| Metric | Before (v1.0.0 broad) | After (v1.0.1 hybrid) |
|--------|------------------------:|------------------------:|
| delta_count | 352 | **0** |
| new | 274 | 0 |
| changed | 2 | 0 |
| moved | 76 | 0 |
| critical | 305 | 0 |
| internal | 26 | 0 |

Hybrid scan on unchanged workspace also reports **~151 undiscovered root files** scanned silently (no Hebrew deltas — files without unmatched visible Hebrew).

---

## Controlled verification

### Unit smoke (`hebrew-copy-delta-gate-smoke.mjs`) — 15/15 PASS

### Probe (`hebrew-copy-delta-gate-probe.mjs`) — 7/7 PASS

| Scenario | Result |
|----------|--------|
| Add Hebrew | 1 `new` |
| Change | 1 `changed` |
| Move cross-file | 1 `moved` |
| Delete | 1 `removed` |
| Internal | `internal_only`, suppressed |
| Parent decision | `critical` / `pending_owner_review` |
| Learning content | `pending_expert_review` |

### E2E (`hebrew-copy-delta-gate-e2e.mjs`) — 4/4 PASS

Uses actual `runDeltaGate()` with temp files under scan roots:

1. Clean workspace → 0 deltas
2. New file `components/learning/_hebrew-delta-e2e-probe.js` → exactly 1 `new` for probe string
3. New file `utils/parent-report-language/_hebrew-delta-e2e-critical-probe.js` → `critical` / `pending_owner_review`
4. After cleanup → 0 deltas

---

## Commands run

| Command | Result |
|---------|--------|
| `npm run hebrew:baseline` | PASS — 77,340 records v1.0.1 |
| `npm run hebrew:delta:smoke` | PASS — 15+7+4 |
| `npm run hebrew:delta:dry` | PASS — delta_count 0 |
| `node scripts/hebrew-copy-delta-gate.mjs --warn-only` | PASS |
| `npm run hebrew:delta:review` | PASS — 0 rows |
| `node scripts/parent-report-hebrew-copy-guard.mjs` | PASS |
| `node scripts/hebrew-copy-delta-noise-analysis.mjs` | PASS |

---

## Remaining known limitations

1. New files **outside** `DOMAIN_SCAN_ROOTS` not auto-discovered.
2. `pages/student/worksheet/` excluded (inventory align).
3. Inventory noise suppressions apply only to baseline-known files.
4. No CI/hooks — manual warn-only workflow.

---

## Git verification

### `git status --short`

```
 M docs/hebrew-copy/HEBREW_COPY_DELTA_GATE_USAGE.md
 M package.json
 M scripts/hebrew-copy-baseline-build.mjs
 M scripts/hebrew-copy-delta-gate.mjs
 M scripts/lib/hebrew-copy-scan-lib.mjs
 M scripts/tests/hebrew-copy-delta-gate-smoke.mjs
?? data/hebrew-copy-baseline/v1.0.1/
?? scripts/hebrew-copy-delta-noise-analysis.mjs
?? scripts/tests/fixtures/
?? scripts/tests/hebrew-copy-delta-gate-probe.mjs
?? scripts/tests/hebrew-copy-delta-gate-e2e.mjs
```

### `git diff --stat`

```
 docs/hebrew-copy/HEBREW_COPY_DELTA_GATE_USAGE.md |  52 +++--
 package.json                                     |   2 +-
 scripts/hebrew-copy-baseline-build.mjs           |   5 +-
 scripts/hebrew-copy-delta-gate.mjs               |  48 ++++-
 scripts/lib/hebrew-copy-scan-lib.mjs             | 210 ++++++++++++++++++++-
 scripts/tests/hebrew-copy-delta-gate-smoke.mjs   |  45 ++++-
 6 files changed, 333 insertions(+), 29 deletions(-)
```

### Confirmations

- No product Hebrew copy changed
- No product logic / reports / DB / API / routes / auth / scoring changed
- No CI, hooks, or blocking enforcement added
- No pending copy marked approved

---

## Review package

`review-packages/hebrew-copy-delta-gate-noise-reduction-review.zip` (includes baseline v1.0.1 artifacts)
