# Hebrew Copy Delta Summary

Generated: 2026-05-29T19:34:05.958Z

## Gate result

| Metric | Value |
|--------|------:|
| Baseline version | v1.0.0 |
| Baseline records | 77340 |
| Files scanned | 304 |
| Current strings | 35193 |
| **Delta count** | **352** |
| Gate pass | yes |
| Critical new/changed | 236 |
| Medium new/changed | 0 |
| Unreviewed critical introduced | yes |

## By change type

- moved: 76
- new: 273
- new_template: 1
- changed: 2

## By risk level

- critical: 305
- internal: 26
- low: 21

## Top critical deltas (first 15)

1. **moved** — `סקירת דוח ההורים` (data/help-center/content/parent-report.js:18)
2. **new** — `דוח מקוצר לעומת דוח מפורט — מתי משתמשים בכל אחד.` (data/help-center/content/parent-report.js:19)
3. **moved** — `דוח` (data/help-center/content/parent-report.js:20)
4. **moved** — `סקירה` (data/help-center/content/parent-report.js:20)
5. **new** — `דוח מקוצר` (data/help-center/content/parent-report.js:22)
6. **moved** — `דוח מפורט` (data/help-center/content/parent-report.js:23)
7. **new** — `דוח מקוצר` (data/help-center/content/parent-report.js:26)
8. **new** — `מציג תמונת מצב מהירה: ביצועים, מגמות והמלצות עיקריות.` (data/help-center/content/parent-report.js:27)
9. **new** — `דף דוח הורים מקוצר` (data/help-center/content/parent-report.js:29)
10. **new** — `דוח מפורט` (data/help-center/content/parent-report.js:30)
11. **new** — `כולל פירוט לפי מקצוע, נושאים, מכתב הורי והמלצות ממוקדות.` (data/help-center/content/parent-report.js:31)
12. **new** — `דף דוח מפורט` (data/help-center/content/parent-report.js:32)
13. **moved** — `כרטיס סיכום` (data/help-center/content/parent-report.js:39)
14. **new** — `החלק העליון של הדוח — תמונת מצב כללית.` (data/help-center/content/parent-report.js:40)
15. **moved** — `סיכום` (data/help-center/content/parent-report.js:41)

> Baseline is known-current-state only — not approval. Review workbook: `reports/hebrew-copy-delta-review.xlsx`
